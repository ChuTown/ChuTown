//imports for drawing Images
import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;

import java.util.ArrayList;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JComponent;
import javax.swing.JFrame;
import java.awt.Font;
import java.awt.Toolkit;

public class ChuTowerDefenseDriver extends JComponent implements KeyListener, MouseListener, MouseMotionListener {
    //instance variables 
    
    // instantiating the width and height of the GUI
    private int WIDTH;
    private int HEIGHT;
    
    // instantiating the array of enemies.
    private ArrayList<ChuEnemy> enemies;
    
    //instantiating the arrayList of towers
    private ArrayList<ChuTower> towers;
    
    //instantiating my bullets
    private ArrayList<ChuBullet> bullets;
    
    // int to tell what I am selecting
    private int selected;
    

    private int money;
     
    private boolean buttonPress;
   
    private int rigbyRotation;
    
    private int spawnCooldown;
    
    private int amountSpawned;
    
    private int roundAmount;
    
    private double spawnTime, spawnRate;
    
    private int health;
    
    private boolean gameState;
    
    private int enemySpeed, enemyHealth;
    
    private int enemiesDied;
    
    private int enemyIncreaseRate;
    
    private int currentRound;
     
    //Default Constructor    
    public ChuTowerDefenseDriver() {   
        spawnTime = 0;
        spawnRate = 500;
        roundAmount = 1;
        amountSpawned = 0;
        gameState = true;
        
        // assigning the width and height of the gui
        WIDTH = 1092;
        HEIGHT = 788;
         
        // assigning my enemies
        enemies = new ArrayList<>();
        
        // assigning my bullets
        bullets = new ArrayList<>();      
        
        //assigning tower
        towers = new ArrayList<>();
        
        enemyIncreaseRate = 1;      
      
        spawnCooldown = 0; 
        
        // assigning money
        money = 30;
        
        // assigning what the mouse is selected by default.
        selected = 0;
        
        rigbyRotation = 0;
        
        buttonPress = false;
        
        health = 100;
        
        enemySpeed = 1;
        enemyHealth = 1;
        enemiesDied = 0;
        
        currentRound = 0;
        
        
        //Setting up the GUI
        JFrame gui = new JFrame(); //This makes the gui box
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Makes sure your progam can close.
        gui.setTitle("Chu's Tower Defense"); //This is the title of the game.
        gui.setPreferredSize(new Dimension(WIDTH + 5, HEIGHT + 30)); // Setting the size for GUI
        gui.setResizable(false); // Makes it so that the GUI cant be resized
        gui.getContentPane().add(this); // Adding this class to the gui
        
        /*If after you finish everything, you can declare your buttons or other things
        *at this spot. AFTER gui.getContentPane().add(this) and BEFORE gui.pack();
        */

        gui.pack(); //Packs everything together
        gui.setLocationRelativeTo(null); //Makes so the gui opens in the center of screen
        gui.setVisible(true); //Makes the gui visible
        gui.addKeyListener(this);//stating that this object will listen to the keyboard
        gui.addMouseListener(this); //stating that this object will listen to the Mouse
        gui.addMouseMotionListener(this); //stating that this object will acknowledge when the Mouse moves

    }
    //This method will acknowledge user input
    public void keyPressed(KeyEvent e) {
        //getting the key pressed
        int saveCode = e.getKeyCode();       
        System.out.println(saveCode);
        
  
        
    }   
    //All your UI drawing goes in here
    public void paintComponent(Graphics g) {   
        
        // drawing the monke track :)
        Image imgBackground = Toolkit.getDefaultToolkit().getImage(getClass().getResource("tower defense track.png")); 
        g.drawImage(imgBackground, 0, 0, WIDTH, HEIGHT, null);
        
        Image rotateArrow = Toolkit.getDefaultToolkit().getImage(getClass().getResource("rotating arrow.png"));
        g.drawImage(rotateArrow, 1010,470, 48,42,null);
        //declaring all rigby directions
        Image rigbyUp = Toolkit.getDefaultToolkit().getImage(getClass().getResource("rigby looking up.png"));
        Image rigbyRight = Toolkit.getDefaultToolkit().getImage(getClass().getResource("rigby looking right.png"));
        Image rigbyDown = Toolkit.getDefaultToolkit().getImage(getClass().getResource("rigby looking down.png"));
        Image rigbyLeft = Toolkit.getDefaultToolkit().getImage(getClass().getResource("rigby looking left.png"));
            
        if (rigbyRotation == 0) {
            g.drawImage(rigbyUp, 995,76, 64,64,null);
        }
        else if (rigbyRotation == 1) {
            g.drawImage(rigbyRight, 995,76, 64,64,null);
        }
        else if (rigbyRotation == 2) {
            g.drawImage(rigbyDown, 995,76, 64,64,null);
        }
        else if (rigbyRotation == 3) {
            g.drawImage(rigbyLeft, 995,76, 64,64,null);
        }
        else {
            
        }
        
        // showing arrow selector
        Image arrow = Toolkit.getDefaultToolkit().getImage(getClass().getResource("arrow selector.png"));
        if (selected == 0) {
        
        }
        else if (selected == 1) {
            g.drawImage(arrow, 887, 75, 100, 50, null);
        }
       
        
        Image buttonUnpressed = Toolkit.getDefaultToolkit().getImage(getClass().getResource("buttonUnpressed.png")); 
        Image buttonPressed = Toolkit.getDefaultToolkit().getImage(getClass().getResource("buttonPressed.png"));  
        
        Image daBurgerDed = Toolkit.getDefaultToolkit().getImage(getClass().getResource("gameover.png"));
        
        if (buttonPress == true) {
            
        }
        else {
            g.drawImage(buttonUnpressed,20 ,28,76,30, null);
        }
     
         //heart    
        g.setColor(Color.BLACK);
        Font f = new Font("Arial", Font.BOLD, 25);
        g.setFont(f);
        g.drawString(" " + health, 1025 , 745);
        
        //currentRound
        g.drawString(" " + currentRound, 1042 , 609);
        
        //text money
        g.drawString(" " + money, 1027 , 697);
      
        //text enemies dead
        g.drawString(" " + enemiesDied, 1024 , 645);
        
        
        //drawing da tower??
        for (int i = 0; i < towers.size(); i++) {
            towers.get(i).drawSelf(g);
        }
        
     
        //Drawing the enemy.  
        
        for (int i = 0; i < enemies.size(); i++) {   
                enemies.get(i).drawSelf(g);                   
        }
       
        
        //drawing the bullet
        for (int j = 0; j < bullets.size(); j ++) {
            bullets.get(j).drawSelf(g);
        }
        
        if (gameState == false) {
            g.drawImage(daBurgerDed,0 ,0,WIDTH,HEIGHT, null);
            g.setColor(Color.WHITE);
            Font z = new Font("Arial", Font.PLAIN, 35);
            g.setFont(z);
            g.drawString("" + currentRound,580 ,138);
            g.drawString("" + enemiesDied, 535, 225);
     
        }
        
    }
    public void loop(){
        
        if (health <= 0) {
            gameState = false;
        }
       
        
        if (buttonPress == true && gameState == true) {
            spawnRound();
        }
        
        
        //telling the enemy how to move
        for (int i = 0; i < enemies.size(); i++) {
                enemies.get(i).act(WIDTH, HEIGHT);                    
        }
          
        for (int x = 0; x < enemies.size(); x++) {         
           for (int y = 0; y < towers.size(); y ++) {
               towers.get(y).shoot(enemies.get(x), bullets);
           }
        }
        
        // telling every bullet that's made, how to move. 
        for (int j = 0; j < bullets.size(); j ++) {          
                 bullets.get(j).move();  
        }
        
        for (int i = 0; i < enemies.size(); i++) {
            if ( enemies.get(i).getReachedEnd() == true) {
                    health = health - enemies.get(i).getHp();
                    enemies.remove(i);
            }
        }
                

        // checking the distance of every bullet and every enemy. making bullets dissapear when they hit.
        for (int j = bullets.size() - 1; j >= 0; j --) {
            for (int x = enemies.size() - 1; x >= 0;  x--) {
                
                if (j >=0 && j< bullets.size() && x >= 0 && x < enemies.size() && enemies.get(x).handleCollisions(bullets.get(j)) == true) {            
                    bullets.remove(j); 
                    
                    
                    enemies.get(x).setHp(enemies.get(x).getHp() - 1);    
                
                    if (enemies.get(x).getHp() == 0) {
                        enemies.remove(x);
                        money++;  
                        enemiesDied++;
                    }
                }
            }
        }
        
        
        //deleting the bullets when it hits the edges of the screen
        for (int j = bullets.size() - 1; j >= 0; j --) {
            if (bullets.get(j).getX() > WIDTH || bullets.get(j).getX() < 0 || bullets.get(j).getY() > HEIGHT || bullets.get(j).getY() < 0) {
                bullets.remove(j);
            }
        }
        
        // if you're dead remove everything
        if (gameState == false) {
            
            for (int j = towers.size() - 1; j >= 0; j --) {
                towers.remove(j);
            }
            for (int j = enemies.size() - 1; j >= 0; j --) {
                enemies.remove(j);
            }
        }
       
        
        repaint();
    }
    
    public void spawnRound() {
        
        if(System.currentTimeMillis() >= spawnTime + spawnRate) {
            spawnTime = System.currentTimeMillis();
            if (amountSpawned < roundAmount) {
                enemies.add(new ChuEnemy (148 , 3, 25, Color.MAGENTA, enemySpeed, enemyHealth));
                amountSpawned++;
            }
            else if (amountSpawned == roundAmount && enemies.size() == 0) {
                roundAmount = roundAmount + enemyIncreaseRate;
                             
                // make a condition for prime numbers tomorrow.
                currentRound++;
                System.out.println("currentRound: " + currentRound);
                
                if (currentRound % 3 == 0) {    
                    if (spawnRate <= 100) {
                        spawnRate = spawnRate - 50;
                    }  
                    enemyIncreaseRate++;
                }
                if (currentRound % 5 == 0 || currentRound % 3 == 0 || currentRound % 7 == 0) {                                 
                    enemyHealth = enemyHealth + 2;
                }
                
                if (currentRound % 5 == 0 || currentRound % 3 == 0 || currentRound > 15) {                                 
                    enemyHealth = enemyHealth + 1;
                }                 
                
                if (currentRound % 16 == 0) {
                   enemySpeed = enemySpeed + 1;
                }
                if (currentRound % 5 == 0) {
                    enemyIncreaseRate++;    
                }
                
                if (currentRound % 51 == 0 || currentRound % 53 == 0 || currentRound % 55 == 0 || currentRound % 56 == 0 || currentRound % 57 == 0 || currentRound % 58 == 0) {
                   enemyHealth = enemyHealth + 2;
                }
                
            }
        }
        
    }
    //These methods are required by the compiler.  
    //You might write code in these methods depending on your goal.
    public void keyTyped(KeyEvent e) {
        
    }
    public void keyReleased(KeyEvent e){
        
    }
    public void mousePressed(MouseEvent e){
        
    }
    public void mouseReleased(MouseEvent e){
        
    }
    public void mouseClicked(MouseEvent e){
        int xClick = e.getX();
        int yClick = e.getY();
        int mouse = e.getButton();
        
        System.out.println("mouse: " + mouse );
        
        System.out.println("Mouse clicked at " + xClick + ", " + yClick);
        
        if (selected == 0) {
            
            //top right rigby shop
            if (xClick > 988 && xClick < 1073 && yClick > 55 && yClick < 141) {
                if (money >= 15) {
                    selected = 1;
                    System.out.println("selected: " + selected);
                }
            }   
            
            //top left button
            else if (xClick > 20 && xClick < 96 && yClick > 52 && yClick < 81 && buttonPress == false) { 
                buttonPress = true;
            }
            
            //rigby rotator
            else if (xClick > 1009 && xClick < 1059 && yClick > 492 && yClick < 536) {
                System.out.println("rotation arrow being pressed");
                if (rigbyRotation == 0) {
                    rigbyRotation = 1;
                }
                else if (rigbyRotation == 1) {
                    rigbyRotation = 2;
                }
                else if (rigbyRotation == 2) {
                    rigbyRotation = 3;
                }
                else {
                    rigbyRotation = 0;
                }
            }
        }
                                 
        else {
            
            for (int i = 0; i < towers.size(); i++) {
                System.out.println("tower x coordinate : "  + towers.get(i).getxCoordinate());
                System.out.println("tower x coordinate + 32: " +  (towers.get(i).getxCoordinate()+32));
                System.out.println("towers y coordinate : " + towers.get(i).getyCoordinate());
                System.out.println("tower x coordinate + 32: " +  (towers.get(i).getyCoordinate() +32));

                if (xClick > towers.get(i).getxCoordinate() && xClick < towers.get(i).getxCoordinate() + 64 && yClick > towers.get(i).getyCoordinate() && yClick < towers.get(i).getyCoordinate() + 64 ) {
                    System.out.println("U CANT CLICK HERE");
                    selected = 0;
                }

            }    
            
            if (selected == 1) {
                           
                
                if (xClick <= 973) {
   
                    
                    if (xClick > 114 && xClick < 189 && yClick > 0 && yClick < 282) {                       // RIGBY IS FORBIDDEN ON THE TRACK
                        
                    }
                    else if (xClick > 190 && xClick < 375 && yClick > 287 && yClick < 352) {
                    
                    }
                    else if (xClick > 295 && xClick < 375 && yClick > 353 && yClick < 519) {
                    
                    }
                    else if (xClick > 94 && xClick < 295 && yClick > 455 && yClick < 519) {
                    
                    }
                    else if (xClick > 295 && xClick < 375 && yClick > 353 && yClick < 519) {
                    
                    }
                    else if (xClick > 92 && xClick < 173 && yClick > 519 && yClick < 686) {
                    
                    }
                    else if (xClick > 295 && xClick < 375 && yClick > 353 && yClick < 519) {
                    
                    }
                    else if (xClick > 173 && xClick < 552 && yClick > 622 && yClick < 685) {
                    
                    }
                    else if (xClick > 472 && xClick < 552 && yClick > 120 && yClick < 622) {
                    
                    }
                    else if (xClick > 295 && xClick < 375 && yClick > 353 && yClick < 519) {
                    
                    }
                    else if (xClick > 552 && xClick < 928 && yClick > 120 && yClick < 184) {
                    
                    }
                    else if (xClick > 846 && xClick < 928 && yClick > 184 && yClick < 352) {
                    
                    }
                    else if (xClick > 650 && xClick < 730 && yClick > 286 && yClick < 520) {
                    
                    }
                    else if (xClick > 730 && xClick < 905 && yClick > 455 && yClick < 520) {
                    
                    }
                    else if (xClick > 823 && xClick < 899 && yClick > 520 && yClick < 787) {
                    
                    }
                                        
                    else if (rigbyRotation == 0){
                       towers.add(new ChuTower(xClick - 32, yClick - 60, "up"));
                       money = money - 15;
                    }
                    else if (rigbyRotation == 1) {
                       towers.add(new ChuTower(xClick - 32, yClick- 60, "right"));
                       money = money - 15;
                    }
                    else if (rigbyRotation == 2) {
                       towers.add(new ChuTower(xClick - 32, yClick - 60, "down"));
                       money = money - 15;
                    }
                    
                    else {
                       towers.add(new ChuTower(xClick - 32, yClick - 60, "left"));
                       money = money - 15;
                    }
                }
                

                selected = 0;
            }
            // else if for another tower 
        }
    }
    public void mouseEntered(MouseEvent e){
        
    }
    public void mouseExited(MouseEvent e){
        
    }
    public void mouseMoved(MouseEvent e){
        
    }
    public void mouseDragged(MouseEvent e){
        
    }
    public void start(final int ticks){
        Thread gameThread = new Thread(){
            public void run(){
                while(true){
                    loop();
                    try{
                        Thread.sleep(1000 / ticks);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            }
        };	
        gameThread.start();
    }

    public static void main(String[] args)
    {
        ChuTowerDefenseDriver g = new ChuTowerDefenseDriver();
        g.start(60);
    }
}
