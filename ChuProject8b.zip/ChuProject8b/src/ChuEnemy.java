import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JComponent;
import javax.swing.JFrame;
import java.awt.Font;


//SURIEL:  I can't help myself to say this but this class represents 1 enemy.  Not many enemies.  You will construct many enemies later but it represents 1.
//meaning it should have been called Enemy, not Enemies.
public class ChuEnemy {
    //step 1 instance variables 
   // private int health; to be used after turrets are coded.
    
    //type of enemy
    //private String type;
    
    //original placement of the enemy
    private int x;
    private int y;
    
    //size
    private int diameter;
    
    
    //color
    private Color col;
    
    
    //declaring hp
    private int hp;
    
    // declaring alive or dead
    private boolean aliveOrDead; 
    
    //SURIEL:  You should have a variable to make it clear if the Enemy made it to the end
    private boolean reachedEnd;  //write an accessor for this.
    
    
    //speed
    private int speed;
    
    //step 2 default constructors
    public ChuEnemy(int xCoordinate, int yCoordinate, int diameter, Color c, int speed, int hp) {
      //  health = 100; to be used after turrets are coded.
        x = xCoordinate;
        y = yCoordinate;            
        this.diameter = diameter;       
        col = c;        
        this.speed = speed;
        this.hp = hp;
        
        aliveOrDead = true; // Alive by default
        
        reachedEnd = false;//SURIEL:  It ddid not reach the end when it was created.
    }
    
    // getter and setters
    
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getDiameter() {
        return diameter;
    }

    public void setDiameter(int diameter) {
        this.diameter = diameter;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public boolean getAliveOrDead() {
        return aliveOrDead;
    }

    public void setAliveOrDead(boolean aliveOrDead) {
        this.aliveOrDead = aliveOrDead;
    }

    public boolean getReachedEnd() {
        return reachedEnd;
    }

    public void setReachedEnd(boolean reachedEnd) {
        this.reachedEnd = reachedEnd;
    }
    
    
    // interesting methods.
    public void act(int width, int height) {

        if (y <= 308 && x == 148) { 
            y = y + speed;  //DOWN
            //System.out.println("A y = " + y);
        }              
        else if (y >= 309 && y < 359 && x <= 327){
            x = x + speed;
           //System.out.println("B x: " + x);
        }        
        else if (x >= 328 && x <= 378 && y <= 470) {
            y = y + speed;
           //System.out.println("C y: " + y);
        }               
        else if (y >= 471 && y <= 521 &&  x < 337 && x > 128) {
            x = x - speed; //LEFT
            //System.out.println("D x: " + x);
        }      
        else if (x <= 128 && x > 88 && y <= 636) {
            y = y + speed;
            //System.out.println("E y: " + y);     
        }   
        else if (y >= 637 && y <=687 && x < 502) {
            x = x + speed;
            //System.out.println("F x: " + x);
        }      
        else if (x >= 502 &&  x <= 552 && y >= 140) {
            y = y - speed;//UP
            //System.out.println("G y: " + y);
        }   
        else if (y <= 139 && y >= 89 && x < 870) {
            x = x + speed; //RIGHT
            //System.out.println("H x: " + x);
        }
        else if (x >= 870  && x <= 920 && y < 305) {
            y = y + speed;
            //System.out.println("I y: " + y);
        }
        else if (y >= 305 && y <= 350 && x < 886 && x > 680) {
            x = x - speed;
            //System.out.println("J x: " + x);
        }
        else if (x <= 680 && x >= 630 && y <= 470) {
            y = y + speed;
            //System.out.println("K y: " + y);
        }
        else if (y >= 471 && y <= 521 && x <= 847) {
            x = x + speed;
            //System.out.println("L x: " + x);
        }
        else if (x >= 848 && x <= 898 && y <= 787) {
            y = y + speed;
            //System.out.println("M y: " + y);
        }
        else if (y >= 788) {
            reachedEnd = true;  //THIS VARIABLE WILL HELP YOU DETERMEINE WHEN TO HURT THE PLAYER SINCE THE ENEMY REACHED THE END
            //System.out.println("finished!");
        }
    }        
    
    public void drawSelf(Graphics g){
        //Drawing the bubble
        g.setColor(col);
        g.fillOval(x, y, diameter, diameter);
    }
    
    public double distance(int x1, int y1, int x2, int y2) {
        double output;   
        output = Math.sqrt((Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)));
        return output;
    }
    
    public boolean handleCollisions(ChuBullet bullet) {
        boolean output = false;
        
        double distanceFromEnemyToBullet = distance(getX() + diameter/2 , getY() + diameter/2 , bullet.getX() + 8, bullet.getY() + 8);
        
        if (distanceFromEnemyToBullet <= diameter/2 + 8) {
            output = true;
        }
        else {
            output = false;
        }
        
      
        
        return output;
    }
    
    
}