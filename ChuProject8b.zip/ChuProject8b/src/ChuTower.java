import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.util.ArrayList;

public class ChuTower {
    //instance variables 
    private int xCoordinate;
    private int yCoordinate;
    private ArrayList<ChuBullet> bullet;
    private boolean enemyInRange;
    private String direction;
    private int shootingCooldown;
 

    // 5 parameterized constructors because
    public ChuTower (int x, int y, String direction) {
        this.xCoordinate = x;
        this.yCoordinate = y;  
        this.direction = direction;
        enemyInRange = true;
        shootingCooldown = 0;
        
    }
    //step 3 toString method
    public String toString () {
        String output;
        output = "The tower is at coordinates: " + xCoordinate + ", " + yCoordinate;
        return output;
    }
    
    //step 4 accessor mutator
    
     public int getxCoordinate() {
        return xCoordinate;
    }

    public void setxCoordinate(int xCoordinate) {
        this.xCoordinate = xCoordinate;
    }

    public int getyCoordinate() {
        return yCoordinate;
    }

    public void setyCoordinate(int yCoordinate) {
        this.yCoordinate = yCoordinate;
    }

    public ArrayList<ChuBullet> getBullet() {
        return bullet;
    }

    public void setBullet(ArrayList<ChuBullet> bullet) {
        this.bullet = bullet;
    }

    public boolean isEnemyInRange() {
        return enemyInRange;
    }

    public void setEnemyInRange(boolean enemyInRange) {
        this.enemyInRange = enemyInRange;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }
    
    
     // step 5 interesting methods   
    
    public void drawSelf(Graphics g){
            if (this.getDirection() == "down") {
                Image imgTower = Toolkit.getDefaultToolkit().getImage(getClass().getResource("rigby looking down.png"));
                g.drawImage(imgTower, getxCoordinate(), getyCoordinate(), 64, 64, null);
                shootingCooldown++;       
            }
            else if (this.getDirection() == "up") {
                Image imgTower = Toolkit.getDefaultToolkit().getImage(getClass().getResource("rigby looking up.png"));
                g.drawImage(imgTower, getxCoordinate(), getyCoordinate(), 64, 64, null);
                shootingCooldown++;    
            }
            else if (this.getDirection() == "left") {
                Image imgTower = Toolkit.getDefaultToolkit().getImage(getClass().getResource("rigby looking left.png"));
                g.drawImage(imgTower, getxCoordinate(), getyCoordinate(), 64, 64, null);
                shootingCooldown++;  
            }
            else if (this.getDirection() == "right") {
                Image imgTower = Toolkit.getDefaultToolkit().getImage(getClass().getResource("rigby looking right.png"));
                g.drawImage(imgTower, getxCoordinate(), getyCoordinate(), 64, 64, null);
                shootingCooldown++;  
            }
            
    }
    
    public double distance(int x1, int y1, int x2, int y2) {
        double output;   
        output = Math.sqrt((Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)));
        return output;
    }
    
    public boolean enemyInRange(ChuEnemy enemy) {
        
        boolean enemyInRange;
        
        int range = 250;
        
        double distanceFromTowerToEnemy = distance(getxCoordinate() + 16, getyCoordinate() + 16, enemy.getX() + 13, enemy.getY() + 13);
        
        if (range > distanceFromTowerToEnemy ) {
            return true;
        }
        else {
            return false;
        }       
    }
    
    public void shoot(ChuEnemy enemy, ArrayList<ChuBullet> bullets)
    {
        if(enemyInRange(enemy) && shootingCooldown%15 == 0) {
                                           
            if (direction == "down") {
                if (enemy.getY() > yCoordinate && enemy.getX() < xCoordinate + 62 && enemy.getX() > xCoordinate - 30) {                    
                    ChuBullet b = new ChuBullet(this.getxCoordinate()+10, this.getyCoordinate()+45, 0, 8);      //vx = 5 , vy =0        <---this was a comment trying to warn you about this, when we started we started with RIGHT
                    bullets.add(b);
                }
            }
            else if (direction == "up" && enemy.getX() < xCoordinate + 62 && enemy.getX() > xCoordinate - 30 ) {
                if (enemy.getY() < yCoordinate) {
                    ChuBullet b = new ChuBullet(this.getxCoordinate()+15, this.getyCoordinate()+10, 0,-8);      //vx = 5 , vy =0      <--this is the result of blind copy and paste....  
                    bullets.add(b);  
                }
            }
            else if (direction == "left" && enemy.getY() < yCoordinate + 62 && enemy.getY() > yCoordinate - 30 ) {
                if (enemy.getX() < xCoordinate) {
                    ChuBullet b = new ChuBullet(this.getxCoordinate()+5, this.getyCoordinate()+40, -8, 0);      //vx = 5 , vy =0          
                    bullets.add(b);
                }
            }
            else if (direction == "right" && enemy.getY() < yCoordinate + 62 && enemy.getY() > yCoordinate - 30 ) {
                if (enemy.getX() > xCoordinate) {
                    ChuBullet b = new ChuBullet(this.getxCoordinate()+30, this.getyCoordinate()+45, 8, 0);      //vx = 5 , vy =0          
                    bullets.add(b);
                }
            } 
        }
    }
      
}
