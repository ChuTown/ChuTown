import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JComponent;
import javax.swing.JFrame;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

public class ChuBullet{
    // instance variables
    private int x;
    private int y;
    private boolean handleCollision;
    private Image bullet;
    
    private int vx;
    private int vy;
    
    // default constructors
    public ChuBullet (int startX , int startY, int velx, int vely) {
        x = startX + 15;
        y = startY;
        handleCollision = false; // has not touched the enemy        
        bullet = Toolkit.getDefaultToolkit().getImage(getClass().getResource("blue bullet.png"));
        vx = velx;
        vy = vely;
        
    }
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public boolean isHandleCollision() {
        return handleCollision;
    }

    public void setHandleCollision(boolean handleCollision) {
        this.handleCollision = handleCollision;
    }

 
    public void drawSelf(Graphics g) {
        //drawing the bullet
        g.drawImage(bullet, x, y, null);
        
    }
    
    
  
    public void move() {
        {
           //yep that's it.
            x = x + vx;
            y = y + vy;
        }
    }
    
}
